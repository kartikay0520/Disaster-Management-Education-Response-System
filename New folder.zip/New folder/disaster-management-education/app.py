from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/modules')
def modules():
    return render_template('modules.html')

@app.route('/alerts')
def alerts():
    return render_template('alerts.html')

@app.route('/drills')
def drills():
    return render_template('drills.html')

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    questions = [
        {
            'question': 'What should you do during an earthquake?',
            'options': ['Run outside', 'Take cover under a sturdy table', 'Stand near windows', 'Ignore it'],
            'answer': 'Take cover under a sturdy table'
        },
        {
            'question': 'Which number should you call in case of fire emergency in India?',
            'options': ['100', '101', '102', '108'],
            'answer': '101'
        },
        {
            'question': 'What is the safest place during a flood?',
            'options': ['Low-lying areas', 'Rooftop', 'Basement', 'Near river banks'],
            'answer': 'Rooftop'
        }
    ]
    score = 0
    badge = None
    if request.method == 'POST':
        for i, q in enumerate(questions):
            user_answer = request.form.get(f'q{i}')
            if user_answer == q['answer']:
                score += 1
        if score == len(questions):
            badge = 'Gold'
        elif score >= 2:
            badge = 'Silver'
        elif score >= 1:
            badge = 'Bronze'
        else:
            badge = 'Try Again'
        return render_template('quiz.html', questions=questions, score=score, badge=badge, submitted=True)
    return render_template('quiz.html', questions=questions, submitted=False)

if __name__ == '__main__':
    app.run(debug=True)