# Disaster Management Education Project

This project is a web application designed to educate students in schools and colleges about disaster management. It provides interactive modules, region-specific alerts, and virtual drills to enhance learning and preparedness for various disaster scenarios.

## Features

- **Interactive Modules**: Engaging content that teaches students about disaster preparedness and response.
- **Region-Specific Alerts**: Real-time updates and safety information tailored to the user's location.
- **Virtual Drills**: Resources and instructions for conducting drills to practice safety protocols.

## Technologies Used

- **Python**: The backend is built using Python with the Flask framework.
- **HTML/CSS**: The frontend is developed using HTML for structure and CSS for styling.

## Setup Instructions

1. **Clone the Repository**:
   ```
   git clone <repository-url>
   cd disaster-management-education
   ```

2. **Install Dependencies**:
   Make sure you have Python installed. Then, install the required packages using:
   ```
   pip install -r requirements.txt
   ```

3. **Run the Application**:
   Start the Flask server by running:
   ```
   python app.py
   ```
   The application will be accessible at `http://127.0.0.1:5000`.

## Usage

- Navigate to the homepage to explore the available modules, alerts, and drills.
- Use the interactive modules to learn about disaster preparedness.
- Check the alerts page for real-time disaster information relevant to your region.
- Participate in virtual drills to practice safety measures.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.