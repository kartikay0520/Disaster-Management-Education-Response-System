from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/modules')
def modules():
    return render_template('modules.html')

@app.route('/alerts')
def alerts():
    return render_template('alerts.html')

@app.route('/drills')
def drills():
    return render_template('drills.html')

@app.route('/quiz')
def quiz_select():
    return render_template('quiz_select.html')

@app.route('/quiz/<quiz_type>', methods=['GET', 'POST'])
def quiz(quiz_type):
    quizzes = {
        'flood': [
            {
                'question': 'What is the safest place during a flood?',
                'options': ['Low-lying areas', 'Rooftop', 'Basement', 'Near river banks'],
                'answer': 'Rooftop'
            },
            {
                'question': 'What should you avoid during a flood?',
                'options': ['Walking through moving water', 'Listening to authorities', 'Moving to higher ground', 'Staying indoors'],
                'answer': 'Walking through moving water'
            },
            {
                'question': 'Which item is essential in a flood emergency kit?',
                'options': ['Umbrella', 'Flashlight', 'Sunscreen', 'Snow boots'],
                'answer': 'Flashlight'
            }
        ],
        'earthquake': [
            {
                'question': 'What should you do during an earthquake?',
                'options': ['Run outside', 'Take cover under a sturdy table', 'Stand near windows', 'Ignore it'],
                'answer': 'Take cover under a sturdy table'
            },
            {
                'question': 'Where is the safest place to be during an earthquake?',
                'options': ['Near glass doors', 'Under heavy furniture', 'In an elevator', 'On a balcony'],
                'answer': 'Under heavy furniture'
            },
            {
                'question': 'What should you avoid after an earthquake?',
                'options': ['Checking for injuries', 'Using elevators', 'Listening to news', 'Helping others'],
                'answer': 'Using elevators'
            }
        ],
        'tsunami': [
            {
                'question': 'What is a warning sign of a tsunami?',
                'options': ['Sudden rise in temperature', 'Rapidly receding ocean water', 'Heavy rainfall', 'Strong winds'],
                'answer': 'Rapidly receding ocean water'
            },
            {
                'question': 'Where should you go during a tsunami warning?',
                'options': ['Beach', 'Low-lying areas', 'High ground', 'Stay at home'],
                'answer': 'High ground'
            },
            {
                'question': 'What should you do after a tsunami?',
                'options': ['Return to the coast immediately', 'Wait for official all-clear', 'Swim in the ocean', 'Ignore warnings'],
                'answer': 'Wait for official all-clear'
            }
        ]
    }

    questions = quizzes.get(quiz_type)
    if not questions:
        return render_template('quiz_not_found.html', quiz_type=quiz_type)

    score = 0
    badge = None
    if request.method == 'POST':
        for i, q in enumerate(questions):
            user_answer = request.form.get(f'q{i}')
            if user_answer == q['answer']:
                score += 1
        if score == len(questions):
            badge = 'Gold'
        elif score >= 2:
            badge = 'Silver'
        elif score >= 1:
            badge = 'Bronze'
        else:
            badge = 'Try Again'
        return render_template('quiz.html', questions=questions, score=score, badge=badge, submitted=True, quiz_type=quiz_type)
    return render_template('quiz.html', questions=questions, submitted=False, quiz_type=quiz_type)

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    feedbacks = []
    if request.method == 'POST':
        user_feedback = request.form.get('feedback')
        if user_feedback:
            with open('feedback.txt', 'a', encoding='utf-8') as f:
                f.write(user_feedback + '\n')
            return redirect(url_for('feedback'))
    try:
        with open('feedback.txt', 'r', encoding='utf-8') as f:
            feedbacks = f.readlines()
    except FileNotFoundError:
        feedbacks = []
    return render_template('feedback.html', feedbacks=feedbacks)

# ...existing code...

@app.route('/disasters/<disaster_type>')
def disaster_info(disaster_type):
    disaster_data = {
        'flood': {
            'name': 'Flood',
            'precautions': [
                "Move to higher ground immediately.",
                "Do not walk, swim, or drive through flood waters.",
                "Keep emergency supplies ready.",
                "Listen to weather updates and alerts."
            ],
            'donts': [
                "Don't touch electrical equipment if wet.",
                "Don't ignore evacuation orders.",
                "Don't drink flood water."
            ],
            'events': [
                "2008 Kosi River Flood, Bihar, India",
                "2014 Kashmir Floods, India",
                "2015 Chennai Floods, India"
            ]
        },
        'earthquake': {
            'name': 'Earthquake',
            'precautions': [
                "Drop, Cover, and Hold On during shaking.",
                "Stay away from windows and heavy objects.",
                "Secure heavy items in your home.",
                "Have an emergency kit ready."
            ],
            'donts': [
                "Don't run outside during shaking.",
                "Don't use elevators.",
                "Don't stand near glass or under heavy fixtures."
            ],
            'events': [
                "2001 Gujarat Earthquake, India",
                "2015 Nepal Earthquake",
                "1934 Bihar-Nepal Earthquake"
            ]
        },
        'tsunami': {
            'name': 'Tsunami',
            'precautions': [
                "Move to higher ground immediately after an earthquake near the coast.",
                "Follow evacuation orders.",
                "Stay away from the beach after strong tremors.",
                "Listen to official warnings."
            ],
            'donts': [
                "Don't go to the shore to watch the waves.",
                "Don't ignore natural warnings like receding water.",
                "Don't return until authorities declare it safe."
            ],
            'events': [
                "2004 Indian Ocean Tsunami",
                "2011 Tōhoku Tsunami, Japan"
            ]
        }
    }
    info = disaster_data.get(disaster_type)
    if not info:
        return render_template('disaster_not_found.html', disaster_type=disaster_type)
    return render_template('disaster_info.html', info=info)

# ...existing code...

@app.route('/disasters')
def disasters():
    return render_template('disasters.html')

# ...existing code...    
# ...existing code...
if __name__ == '__main__':
    app.run(debug=True)